package com.birdhunt

data class Bird(
    var name: String = "",
    var description: String = "",
    var location: String = "",
    var url: String = ""
)